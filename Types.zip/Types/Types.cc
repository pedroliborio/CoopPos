/*
 * Types.cpp
 *
 *  Created on: Jan 18, 2017
 *      Author: liborio
 */

#include <Types/Types.h>

namespace Localization {

Types::Types() {
    // TODO Auto-generated constructor stub

}

Types::~Types() {
    // TODO Auto-generated destructor stub
}

} /* namespace Localization */
